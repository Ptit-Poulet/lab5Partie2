﻿namespace _2230912_2130331_Lab5Partie2.Models.Base
{
    public class ModelBase
    {

    }
}
